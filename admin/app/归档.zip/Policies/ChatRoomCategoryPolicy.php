<?php

namespace App\Policies;

use App\Models\ChatRoomCategory;
use App\Models\User;

class ChatRoomCategoryPolicy
{
    public function before(User $user): ?bool
    {
        return $user->isSuperAdmin() ? true : null;
    }

    public function viewAny(User $user): bool { return $user->can('chat_room_category.view'); }
    public function view(User $user, ChatRoomCategory $r): bool   { return $user->can('chat_room_category.view'); }
    public function create(User $user): bool  { return $user->can('chat_room_category.create'); }
    public function update(User $user, ChatRoomCategory $r): bool { return $user->can('chat_room_category.update'); }
    public function delete(User $user, ChatRoomCategory $r): bool { return $user->can('chat_room_category.delete'); }
}
