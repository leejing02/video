<?php

namespace App\Policies;

use App\Models\SensitiveWord;
use App\Models\User;

class SensitiveWordPolicy
{
    public function before(User $user): ?bool
    {
        return $user->isSuperAdmin() ? true : null;
    }

    public function viewAny(User $user): bool { return $user->can('sensitive_word.view'); }
    public function view(User $user, SensitiveWord $r): bool   { return $user->can('sensitive_word.view'); }
    public function create(User $user): bool  { return $user->can('sensitive_word.create'); }
    public function update(User $user, SensitiveWord $r): bool { return $user->can('sensitive_word.update'); }
    public function delete(User $user, SensitiveWord $r): bool { return $user->can('sensitive_word.delete'); }
}
