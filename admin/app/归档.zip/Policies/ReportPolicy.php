<?php

namespace App\Policies;

use App\Models\Report;
use App\Models\User;

class ReportPolicy
{
    public function before(User $user): ?bool
    {
        return $user->isSuperAdmin() ? true : null;
    }

    public function viewAny(User $user): bool { return $user->can('report.view'); }
    public function view(User $user, Report $r): bool   { return $user->can('report.view'); }
    public function create(User $user): bool  { return false; } // 用户端创建走 API
    public function update(User $user, Report $r): bool { return $user->can('report.handle'); }
    public function delete(User $user, Report $r): bool { return $user->can('report.handle'); }
}
