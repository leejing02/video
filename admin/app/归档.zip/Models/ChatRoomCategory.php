<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class ChatRoomCategory extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 'slug', 'icon', 'cover', 'description',
        'sort', 'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'sort'      => 'integer',
    ];

    protected static function booted(): void
    {
        static::saving(function (ChatRoomCategory $c) {
            if (empty($c->slug)) {
                $c->slug = Str::slug($c->name) . '-' . Str::random(4);
            }
        });
    }

    public function rooms(): HasMany
    {
        return $this->hasMany(ChatRoom::class, 'category_id');
    }

    public function scopeActive($q)
    {
        return $q->where('is_active', true);
    }
}
