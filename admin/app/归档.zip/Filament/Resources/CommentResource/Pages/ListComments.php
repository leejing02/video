<?php

namespace App\Filament\Resources\CommentResource\Pages;

use App\Filament\Resources\CommentResource;
use App\Models\Comment;
use Filament\Actions;
use Filament\Resources\Components\Tab;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Database\Eloquent\Builder;

class ListComments extends ListRecords
{
    protected static string $resource = CommentResource::class;

    protected function getHeaderActions(): array
    {
        return [Actions\CreateAction::make()];
    }

    public function getTabs(): array
    {
        $pendingCount = Comment::where('audit_status', Comment::AUDIT_PENDING)->count();
        return [
            'all'      => Tab::make('全部'),
            'pending'  => Tab::make('待审核')
                ->modifyQueryUsing(fn (Builder $q) => $q->where('audit_status', Comment::AUDIT_PENDING))
                ->badge($pendingCount)
                ->badgeColor('warning'),
            'approved' => Tab::make('已通过')
                ->modifyQueryUsing(fn (Builder $q) => $q->where('audit_status', Comment::AUDIT_APPROVED)),
            'rejected' => Tab::make('已拒绝')
                ->modifyQueryUsing(fn (Builder $q) => $q->where('audit_status', Comment::AUDIT_REJECTED)),
        ];
    }
}
