<?php

namespace App\Filament\Resources\ReportResource\Pages;

use App\Filament\Resources\ReportResource;
use App\Models\Report;
use Filament\Resources\Components\Tab;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Database\Eloquent\Builder;

class ListReports extends ListRecords
{
    protected static string $resource = ReportResource::class;

    public function getTabs(): array
    {
        return [
            'pending'   => Tab::make('待处理')
                ->modifyQueryUsing(fn (Builder $q) => $q->where('status', Report::STATUS_PENDING))
                ->badge(Report::pending()->count())
                ->badgeColor('danger'),
            'handled'   => Tab::make('已处理')
                ->modifyQueryUsing(fn (Builder $q) => $q->where('status', Report::STATUS_HANDLED)),
            'dismissed' => Tab::make('已驳回')
                ->modifyQueryUsing(fn (Builder $q) => $q->where('status', Report::STATUS_DISMISSED)),
            'all'       => Tab::make('全部'),
        ];
    }
}
