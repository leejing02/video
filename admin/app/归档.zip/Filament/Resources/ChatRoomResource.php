<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ChatRoomResource\Pages;
use App\Models\ChatRoom;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class ChatRoomResource extends Resource
{
    protected static ?string $model = ChatRoom::class;

    protected static ?string $navigationIcon  = 'heroicon-o-chat-bubble-left-ellipsis';
    protected static ?string $navigationGroup = '聊天';
    protected static ?string $navigationLabel = '聊天室';
    protected static ?string $modelLabel      = '聊天室';
    protected static ?int $navigationSort     = 50;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('基础信息')->columns(2)->schema([
                Forms\Components\TextInput::make('name')->label('名称')->required(),
                Forms\Components\TextInput::make('slug')
                    ->label('Slug')
                    ->unique(ignoreRecord: true)
                    ->helperText('留空自动生成'),
                Forms\Components\Select::make('kind')
                    ->label('类型')
                    ->options([
                        ChatRoom::KIND_GLOBAL => '全局群聊（首页）',
                        ChatRoom::KIND_GROUP  => '普通群',
                        ChatRoom::KIND_DIRECT => '私聊',
                    ])
                    ->default(ChatRoom::KIND_GROUP)
                    ->required(),
                Forms\Components\Select::make('category_id')
                    ->label('群分类')
                    ->relationship('category', 'name', fn ($q) => $q->where('is_active', true))
                    ->searchable()
                    ->preload(),
                Forms\Components\Select::make('owner_id')
                    ->label('群主')
                    ->relationship('owner', 'name')
                    ->searchable(),
                Forms\Components\Toggle::make('is_active')->label('启用')->default(true),
            ]),

            Forms\Components\Section::make('权限与限制')->columns(2)->schema([
                Forms\Components\Toggle::make('all_muted')
                    ->label('全员禁言')
                    ->helperText('打开后只有群主/管理员能发消息'),
                Forms\Components\TextInput::make('member_limit')
                    ->label('成员上限')
                    ->numeric()
                    ->default(0)
                    ->helperText('0 = 不限'),
            ]),

            Forms\Components\Textarea::make('description')->label('简介')->rows(3),

            Forms\Components\FileUpload::make('cover')
                ->label('封面')->image()->directory('chat-rooms'),

            Forms\Components\Section::make('快速添加成员')->schema([
                Forms\Components\Select::make('users')
                    ->label('成员')
                    ->relationship('users', 'name')
                    ->multiple()
                    ->searchable()
                    ->preload()
                    ->helperText('全局群聊不需要指定，所有人都能进；详细成员管理见编辑页底部 Tab'),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('cover')->label('封面')->square(),
                Tables\Columns\TextColumn::make('name')->label('名称')->searchable(),
                Tables\Columns\TextColumn::make('category.name')->label('分类')->badge()->placeholder('—'),
                Tables\Columns\TextColumn::make('kind')
                    ->label('类型')
                    ->colors([
                        'danger'  => ChatRoom::KIND_GLOBAL,
                        'primary' => ChatRoom::KIND_GROUP,
                        'gray'    => ChatRoom::KIND_DIRECT,
                    ])
                    ->formatStateUsing(fn ($s) => match ($s) {
                        ChatRoom::KIND_GLOBAL => '全局',
                        ChatRoom::KIND_GROUP  => '普通群',
                        ChatRoom::KIND_DIRECT => '私聊',
                    }),
                Tables\Columns\TextColumn::make('owner.name')->label('群主'),
                Tables\Columns\TextColumn::make('users_count')->counts('users')->label('成员'),
                Tables\Columns\TextColumn::make('member_limit')
                    ->label('上限')
                    ->formatStateUsing(fn ($s) => $s == 0 ? '不限' : $s),
                Tables\Columns\TextColumn::make('messages_count')->counts('messages')->label('消息数'),
                Tables\Columns\IconColumn::make('all_muted')->boolean()->label('全员禁言'),
                Tables\Columns\IconColumn::make('is_active')->boolean()->label('启用'),
                Tables\Columns\TextColumn::make('last_message_at')->label('最后活跃')->since()->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('kind')
                    ->label('类型')
                    ->options([
                        ChatRoom::KIND_GLOBAL => '全局',
                        ChatRoom::KIND_GROUP  => '普通群',
                        ChatRoom::KIND_DIRECT => '私聊',
                    ]),
                Tables\Filters\SelectFilter::make('category_id')
                    ->label('分类')
                    ->relationship('category', 'name'),
            ])
            ->actions([
                Tables\Actions\Action::make('toggle_all_mute')
                    ->label(fn (ChatRoom $r) => $r->all_muted ? '解除全员禁言' : '全员禁言')
                    ->icon(fn (ChatRoom $r) => $r->all_muted ? 'heroicon-o-megaphone' : 'heroicon-o-no-symbol')
                    ->color(fn (ChatRoom $r) => $r->all_muted ? 'success' : 'danger')
                    ->action(function (ChatRoom $r) {
                        $r->update(['all_muted' => ! $r->all_muted]);
                        Notification::make()->title($r->all_muted ? '已全员禁言' : '已解除')->success()->send();
                    }),

                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make()
                    ->visible(fn (ChatRoom $r) => $r->kind !== ChatRoom::KIND_GLOBAL),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('last_message_at', 'desc');
    }

    public static function getRelations(): array
    {
        return [
            ChatRoomResource\RelationManagers\MembersRelationManager::class,
            ChatRoomResource\RelationManagers\MessagesRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListChatRooms::route('/'),
            'create' => Pages\CreateChatRoom::route('/create'),
            'edit'   => Pages\EditChatRoom::route('/{record}/edit'),
        ];
    }
}
