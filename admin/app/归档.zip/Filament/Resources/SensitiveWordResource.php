<?php

namespace App\Filament\Resources;

use App\Filament\Resources\SensitiveWordResource\Pages;
use App\Models\SensitiveWord;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class SensitiveWordResource extends Resource
{
    protected static ?string $model = SensitiveWord::class;

    protected static ?string $navigationIcon  = 'heroicon-o-no-symbol';
    protected static ?string $navigationGroup = '审核';
    protected static ?string $navigationLabel = '敏感词库';
    protected static ?string $modelLabel      = '敏感词';
    protected static ?int $navigationSort     = 81;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Grid::make(2)->schema([
                Forms\Components\TextInput::make('word')
                    ->label('词')
                    ->required()
                    ->unique(ignoreRecord: true)
                    ->maxLength(120),
                Forms\Components\Select::make('category')
                    ->label('分类')
                    ->options(SensitiveWord::CATEGORIES)
                    ->default('other')
                    ->required(),
                Forms\Components\Select::make('severity')
                    ->label('严重度')
                    ->options([
                        SensitiveWord::SEVERITY_WARN  => 'warn — 命中后标记待审',
                        SensitiveWord::SEVERITY_BLOCK => 'block — 命中直接拒绝',
                    ])
                    ->default(SensitiveWord::SEVERITY_WARN)
                    ->required(),
                Forms\Components\Toggle::make('is_active')->label('启用')->default(true),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('word')->label('词')->searchable()->copyable(),
                Tables\Columns\TextColumn::make('category')
                    ->label('分类')
                    ->formatStateUsing(fn ($s) => SensitiveWord::CATEGORIES[$s] ?? $s)
                    ->colors([
                        'danger'    => 'politics',
                        'warning'   => 'porn',
                        'gray'      => 'other',
                        'primary'   => 'spam',
                        'secondary' => 'violence',
                    ]),
                Tables\Columns\TextColumn::make('severity')
                    ->label('严重度')
                    ->colors([
                        'warning' => SensitiveWord::SEVERITY_WARN,
                        'danger'  => SensitiveWord::SEVERITY_BLOCK,
                    ]),
                Tables\Columns\TextColumn::make('hits')->label('命中次数')->sortable(),
                Tables\Columns\IconColumn::make('is_active')->boolean()->label('启用'),
                Tables\Columns\TextColumn::make('updated_at')->label('更新')->dateTime('m-d H:i')->toggleable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('category')
                    ->label('分类')->options(SensitiveWord::CATEGORIES),
                Tables\Filters\SelectFilter::make('severity')
                    ->label('严重度')->options([
                        SensitiveWord::SEVERITY_WARN  => 'warn',
                        SensitiveWord::SEVERITY_BLOCK => 'block',
                    ]),
                Tables\Filters\TernaryFilter::make('is_active')->label('启用'),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\BulkAction::make('enable')->label('批量启用')
                        ->action(fn ($records) => $records->each->update(['is_active' => true])),
                    Tables\Actions\BulkAction::make('disable')->label('批量停用')
                        ->action(fn ($records) => $records->each->update(['is_active' => false])),
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->headerActions([
                Tables\Actions\Action::make('import')
                    ->label('批量导入')
                    ->icon('heroicon-o-arrow-up-tray')
                    ->form([
                        Forms\Components\Textarea::make('words')
                            ->label('每行一个词')
                            ->required()
                            ->rows(8),
                        Forms\Components\Select::make('category')
                            ->label('统一分类')
                            ->options(SensitiveWord::CATEGORIES)
                            ->default('other'),
                        Forms\Components\Select::make('severity')
                            ->label('统一严重度')
                            ->options([
                                SensitiveWord::SEVERITY_WARN  => 'warn',
                                SensitiveWord::SEVERITY_BLOCK => 'block',
                            ])
                            ->default(SensitiveWord::SEVERITY_WARN),
                    ])
                    ->action(function (array $data) {
                        $count = 0;
                        foreach (preg_split('/\r?\n/', $data['words']) as $w) {
                            $w = trim($w);
                            if ($w === '') continue;
                            SensitiveWord::firstOrCreate(
                                ['word' => $w],
                                ['category' => $data['category'], 'severity' => $data['severity'], 'is_active' => true]
                            );
                            $count++;
                        }
                        \Filament\Notifications\Notification::make()
                            ->title("导入完成：{$count} 条")->success()->send();
                    }),
            ])
            ->defaultSort('id', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListSensitiveWords::route('/'),
            'create' => Pages\CreateSensitiveWord::route('/create'),
            'edit'   => Pages\EditSensitiveWord::route('/{record}/edit'),
        ];
    }
}
