<?php

namespace App\Filament\Resources\ChatRoomCategoryResource\Pages;

use App\Filament\Resources\ChatRoomCategoryResource;
use Filament\Resources\Pages\CreateRecord;

class CreateChatRoomCategory extends CreateRecord
{
    protected static string $resource = ChatRoomCategoryResource::class;
}
