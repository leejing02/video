<?php

namespace App\Filament\Resources\ChatRoomCategoryResource\Pages;

use App\Filament\Resources\ChatRoomCategoryResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListChatRoomCategories extends ListRecords
{
    protected static string $resource = ChatRoomCategoryResource::class;

    protected function getHeaderActions(): array
    {
        return [Actions\CreateAction::make()];
    }
}
