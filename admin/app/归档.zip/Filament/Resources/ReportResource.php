<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ReportResource\Pages;
use App\Models\ChatMessage;
use App\Models\Comment;
use App\Models\Report;
use App\Models\Video;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class ReportResource extends Resource
{
    protected static ?string $model = Report::class;

    protected static ?string $navigationIcon  = 'heroicon-o-flag';
    protected static ?string $navigationGroup = '审核';
    protected static ?string $navigationLabel = '举报处理';
    protected static ?string $modelLabel      = '举报';
    protected static ?int $navigationSort     = 80;

    public static function getNavigationBadge(): ?string
    {
        $n = Report::pending()->count();
        return $n > 0 ? (string) $n : null;
    }

    public static function getNavigationBadgeColor(): ?string
    {
        return 'danger';
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('举报信息（只读）')->columns(2)->schema([
                Forms\Components\TextInput::make('reporter.name')->label('举报人')->disabled(),
                Forms\Components\TextInput::make('reportable_type')->label('对象类型')->disabled(),
                Forms\Components\TextInput::make('reportable_id')->label('对象 ID')->disabled(),
                Forms\Components\TextInput::make('reason')
                    ->label('原因')
                    ->formatStateUsing(fn ($s) => Report::REASONS[$s] ?? $s)
                    ->disabled(),
                Forms\Components\Textarea::make('description')->label('详细描述')->rows(3)->disabled(),
                Forms\Components\TextInput::make('created_at')->label('举报时间')->disabled(),
            ]),
            Forms\Components\Section::make('处理')->schema([
                Forms\Components\Select::make('status')
                    ->label('状态')
                    ->options([
                        Report::STATUS_PENDING   => '待处理',
                        Report::STATUS_HANDLED   => '已处理',
                        Report::STATUS_DISMISSED => '已驳回',
                    ])
                    ->required(),
                Forms\Components\Textarea::make('handler_note')->label('处理备注')->rows(3),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')->sortable(),
                Tables\Columns\TextColumn::make('reporter.name')->label('举报人')->searchable(),
                Tables\Columns\TextColumn::make('reportable_type')
                    ->label('对象类型')
                    ->formatStateUsing(fn ($s) => match (class_basename($s)) {
                        'Video'       => '视频',
                        'Comment'     => '评论',
                        'ChatMessage' => '聊天消息',
                        'User'        => '用户',
                        default       => class_basename($s),
                    }),
                Tables\Columns\TextColumn::make('reportable_id')->label('对象 ID'),
                Tables\Columns\TextColumn::make('reason')
                    ->label('原因')
                    ->formatStateUsing(fn ($s) => Report::REASONS[$s] ?? $s)
                    ->colors([
                        'danger'    => fn ($s) => in_array($s, ['porn', 'violence', 'fraud']),
                        'warning'   => fn ($s) => in_array($s, ['spam', 'politics']),
                        'gray'      => 'other',
                    ]),
                Tables\Columns\TextColumn::make('description')->label('描述')->limit(50)->wrap(),
                Tables\Columns\TextColumn::make('status')
                    ->label('状态')
                    ->colors([
                        'warning' => Report::STATUS_PENDING,
                        'success' => Report::STATUS_HANDLED,
                        'gray'    => Report::STATUS_DISMISSED,
                    ])
                    ->formatStateUsing(fn ($s) => match ($s) {
                        Report::STATUS_PENDING   => '待处理',
                        Report::STATUS_HANDLED   => '已处理',
                        Report::STATUS_DISMISSED => '已驳回',
                    }),
                Tables\Columns\TextColumn::make('handler.name')->label('处理人')->placeholder('—'),
                Tables\Columns\TextColumn::make('created_at')->label('时间')->dateTime('m-d H:i'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->label('状态')
                    ->options([
                        Report::STATUS_PENDING   => '待处理',
                        Report::STATUS_HANDLED   => '已处理',
                        Report::STATUS_DISMISSED => '已驳回',
                    ])
                    ->default(Report::STATUS_PENDING),
                Tables\Filters\SelectFilter::make('reason')
                    ->label('原因')->options(Report::REASONS),
            ])
            ->actions([
                Tables\Actions\Action::make('handle')
                    ->label('处理并删除内容')
                    ->icon('heroicon-o-trash')
                    ->color('danger')
                    ->requiresConfirmation()
                    ->modalDescription('会删除被举报的对象（视频/评论/消息），并把举报标记为已处理')
                    ->action(function (Report $r) {
                        // 删除被举报对象
                        $obj = $r->reportable;
                        if ($obj instanceof Video) {
                            $obj->update(['status' => Video::STATUS_ARCHIVED, 'audit_status' => Video::AUDIT_REJECTED]);
                        } elseif ($obj instanceof Comment) {
                            $obj->delete();
                        } elseif ($obj instanceof ChatMessage) {
                            $obj->update(['is_blocked' => true, 'blocked_reason' => '举报处理']);
                        }
                        $r->update([
                            'status'      => Report::STATUS_HANDLED,
                            'handled_by'  => auth()->id(),
                            'handled_at'  => now(),
                            'handler_note'=> '内容已下架/删除',
                        ]);
                        Notification::make()->title('已处理并下架')->success()->send();
                    }),

                Tables\Actions\Action::make('dismiss')
                    ->label('驳回')
                    ->icon('heroicon-o-x-circle')
                    ->color('gray')
                    ->action(function (Report $r) {
                        $r->update([
                            'status'     => Report::STATUS_DISMISSED,
                            'handled_by' => auth()->id(),
                            'handled_at' => now(),
                        ]);
                        Notification::make()->title('已驳回')->success()->send();
                    }),

                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\BulkAction::make('mass_dismiss')
                        ->label('批量驳回')
                        ->action(fn ($records) => $records->each->update([
                            'status' => Report::STATUS_DISMISSED, 'handled_at' => now(), 'handled_by' => auth()->id(),
                        ])),
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('id', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListReports::route('/'),
            'edit'   => Pages\EditReport::route('/{record}/edit'),
        ];
    }
}
