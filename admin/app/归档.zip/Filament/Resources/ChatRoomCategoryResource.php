<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ChatRoomCategoryResource\Pages;
use App\Models\ChatRoomCategory;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\Str;

class ChatRoomCategoryResource extends Resource
{
    protected static ?string $model = ChatRoomCategory::class;

    protected static ?string $navigationIcon  = 'heroicon-o-tag';
    protected static ?string $navigationGroup = '聊天';
    protected static ?string $navigationLabel = '群分类';
    protected static ?string $modelLabel      = '群分类';
    protected static ?int $navigationSort     = 49;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Grid::make(2)->schema([
                Forms\Components\TextInput::make('name')
                    ->label('名称')
                    ->required()
                    ->live(onBlur: true)
                    ->afterStateUpdated(fn ($state, Forms\Set $set) =>
                        $set('slug', Str::slug($state).'-'.Str::random(4))),
                Forms\Components\TextInput::make('slug')
                    ->label('Slug')
                    ->unique(ignoreRecord: true)
                    ->required(),
                Forms\Components\TextInput::make('icon')
                    ->label('图标（emoji 或 url）')
                    ->placeholder('🎬'),
                Forms\Components\TextInput::make('sort')
                    ->label('排序')
                    ->numeric()
                    ->default(0),
                Forms\Components\Toggle::make('is_active')
                    ->label('启用')
                    ->default(true),
            ]),
            Forms\Components\Textarea::make('description')->label('简介')->rows(3),
            Forms\Components\FileUpload::make('cover')->label('封面')->image()->directory('chat-rooms/categories'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('cover')->label('封面')->square()->size(40),
                Tables\Columns\TextColumn::make('icon')->label('图标'),
                Tables\Columns\TextColumn::make('name')->label('名称')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('rooms_count')
                    ->counts('rooms')
                    ->label('群数量')
                    ->sortable(),
                Tables\Columns\TextColumn::make('sort')->label('排序')->sortable(),
                Tables\Columns\IconColumn::make('is_active')->boolean()->label('启用'),
            ])
            ->filters([
                Tables\Filters\TernaryFilter::make('is_active')->label('启用'),
            ])
            ->reorderable('sort')
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('sort');
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListChatRoomCategories::route('/'),
            'create' => Pages\CreateChatRoomCategory::route('/create'),
            'edit'   => Pages\EditChatRoomCategory::route('/{record}/edit'),
        ];
    }
}
