<?php

namespace App\Filament\Resources\SensitiveWordResource\Pages;

use App\Filament\Resources\SensitiveWordResource;
use Filament\Resources\Pages\CreateRecord;

class CreateSensitiveWord extends CreateRecord
{
    protected static string $resource = SensitiveWordResource::class;
}
