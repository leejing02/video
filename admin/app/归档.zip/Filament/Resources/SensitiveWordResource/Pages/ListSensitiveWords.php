<?php

namespace App\Filament\Resources\SensitiveWordResource\Pages;

use App\Filament\Resources\SensitiveWordResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListSensitiveWords extends ListRecords
{
    protected static string $resource = SensitiveWordResource::class;

    protected function getHeaderActions(): array
    {
        return [Actions\CreateAction::make()];
    }
}
