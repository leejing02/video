<?php

namespace App\Filament\Resources\SensitiveWordResource\Pages;

use App\Filament\Resources\SensitiveWordResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditSensitiveWord extends EditRecord
{
    protected static string $resource = SensitiveWordResource::class;

    protected function getHeaderActions(): array
    {
        return [Actions\DeleteAction::make()];
    }
}
