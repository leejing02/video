<?php

namespace App\Filament\Resources\ChatRoomResource\RelationManagers;

use App\Models\ChatMessage;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Model;

class MessagesRelationManager extends RelationManager
{
    protected static string $relationship = 'messages';
    protected static ?string $title = '消息记录';
    protected static ?string $modelLabel = '消息';

    public function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Textarea::make('content')->label('内容')->disabled()->rows(3),
            Forms\Components\Toggle::make('is_blocked')->label('已屏蔽（用户不可见）'),
            Forms\Components\Textarea::make('blocked_reason')->label('屏蔽原因')->rows(2),
        ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')->sortable(),
                Tables\Columns\TextColumn::make('user.name')->label('发送人')->searchable(),
                Tables\Columns\TextColumn::make('type')
                    ->label('类型')
                    ->colors([
                        'gray'    => 'text',
                        'primary' => 'image',
                        'success' => 'video',
                        'danger'  => 'system',
                    ]),
                Tables\Columns\TextColumn::make('content')->label('内容')->limit(60)->wrap(),
                Tables\Columns\IconColumn::make('is_blocked')->boolean()->label('已屏蔽'),
                Tables\Columns\TextColumn::make('created_at')->label('时间')->since(),
            ])
            ->filters([
                Tables\Filters\TernaryFilter::make('is_blocked')->label('屏蔽状态'),
            ])
            ->actions([
                Tables\Actions\Action::make('block')
                    ->label(fn (ChatMessage $r) => $r->is_blocked ? '取消屏蔽' : '屏蔽（删除）')
                    ->icon(fn (ChatMessage $r) => $r->is_blocked ? 'heroicon-o-eye' : 'heroicon-o-eye-slash')
                    ->color(fn (ChatMessage $r) => $r->is_blocked ? 'gray' : 'danger')
                    ->form([
                        Forms\Components\Textarea::make('reason')
                            ->label('屏蔽原因')
                            ->rows(2)
                            ->visible(fn (ChatMessage $r) => ! $r->is_blocked),
                    ])
                    ->action(function (array $data, ChatMessage $r) {
                        if ($r->is_blocked) {
                            $r->update(['is_blocked' => false, 'blocked_reason' => null]);
                            Notification::make()->title('已恢复')->success()->send();
                        } else {
                            $r->update([
                                'is_blocked' => true,
                                'blocked_reason' => $data['reason'] ?? '违规',
                            ]);
                            Notification::make()->title('已屏蔽')->danger()->send();
                        }
                    }),

                Tables\Actions\DeleteAction::make()->label('彻底删除'),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\BulkAction::make('block_all')
                        ->label('批量屏蔽')
                        ->color('danger')
                        ->action(fn ($records) => $records->each->update([
                            'is_blocked' => true, 'blocked_reason' => '批量屏蔽',
                        ])),
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('id', 'desc');
    }
}
