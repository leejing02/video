<?php

namespace App\Filament\Resources\ChatRoomResource\RelationManagers;

use Filament\Forms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Model;

class MembersRelationManager extends RelationManager
{
    protected static string $relationship = 'users';
    protected static ?string $title = '成员管理';
    protected static ?string $modelLabel = '成员';

    public function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Select::make('role')
                ->label('角色')
                ->options([
                    'owner'  => '群主',
                    'admin'  => '管理员',
                    'member' => '成员',
                ])
                ->default('member')
                ->required(),
            Forms\Components\Toggle::make('muted')->label('永久禁言'),
            Forms\Components\DateTimePicker::make('muted_until')
                ->label('禁言到（临时禁言）')
                ->helperText('过期自动解除；要永久禁言用上面的开关'),
            Forms\Components\Textarea::make('mute_reason')->label('禁言原因')->rows(2),
        ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('name')
            ->columns([
                Tables\Columns\ImageColumn::make('avatar')->circular()->size(36)->label(''),
                Tables\Columns\TextColumn::make('name')->label('昵称')->searchable(),
                Tables\Columns\TextColumn::make('username')->label('用户名'),
                Tables\Columns\TextColumn::make('pivot.role')
                    ->label('群内角色')
                    ->colors([
                        'danger'  => 'owner',
                        'warning' => 'admin',
                        'gray'    => 'member',
                    ])
                    ->formatStateUsing(fn ($s) => match ($s) {
                        'owner'  => '群主',
                        'admin'  => '管理员',
                        'member' => '成员',
                        default  => $s,
                    }),
                Tables\Columns\IconColumn::make('pivot.muted')->boolean()->label('永久禁言'),
                Tables\Columns\TextColumn::make('pivot.muted_until')
                    ->label('禁言到')
                    ->dateTime('m-d H:i')
                    ->placeholder('—'),
                Tables\Columns\TextColumn::make('pivot.joined_at')
                    ->label('加入时间')
                    ->dateTime('Y-m-d')
                    ->placeholder('—'),
            ])
            ->headerActions([
                Tables\Actions\AttachAction::make()
                    ->label('添加成员')
                    ->preloadRecordSelect()
                    ->form(fn (Tables\Actions\AttachAction $action) => [
                        $action->getRecordSelect(),
                        Forms\Components\Select::make('role')
                            ->label('角色')
                            ->options([
                                'owner'  => '群主',
                                'admin'  => '管理员',
                                'member' => '成员',
                            ])
                            ->default('member')->required(),
                    ]),
            ])
            ->actions([
                // 设为管理员
                Tables\Actions\Action::make('make_admin')
                    ->label('设为管理员')
                    ->icon('heroicon-o-star')
                    ->color('warning')
                    ->visible(fn (Model $record) => ($record->pivot->role ?? 'member') === 'member')
                    ->action(function (Model $record) {
                        $this->getOwnerRecord()->users()->updateExistingPivot($record->id, ['role' => 'admin']);
                        Notification::make()->title('已设为管理员')->success()->send();
                    }),

                // 撤销管理员
                Tables\Actions\Action::make('demote')
                    ->label('撤销管理员')
                    ->icon('heroicon-o-arrow-down-circle')
                    ->color('gray')
                    ->visible(fn (Model $record) => ($record->pivot->role ?? '') === 'admin')
                    ->action(function (Model $record) {
                        $this->getOwnerRecord()->users()->updateExistingPivot($record->id, ['role' => 'member']);
                        Notification::make()->title('已撤销')->success()->send();
                    }),

                // 临时禁言（弹窗输 N 小时）
                Tables\Actions\Action::make('mute_temp')
                    ->label('临时禁言')
                    ->icon('heroicon-o-no-symbol')
                    ->color('warning')
                    ->form([
                        Forms\Components\Select::make('hours')
                            ->label('禁言时长')
                            ->options([
                                1   => '1 小时',
                                6   => '6 小时',
                                24  => '1 天',
                                72  => '3 天',
                                168 => '7 天',
                            ])
                            ->default(24)
                            ->required(),
                        Forms\Components\Textarea::make('reason')->label('原因')->rows(2),
                    ])
                    ->action(function (array $data, Model $record) {
                        $this->getOwnerRecord()->users()->updateExistingPivot($record->id, [
                            'muted_until' => now()->addHours((int) $data['hours']),
                            'mute_reason' => $data['reason'] ?? null,
                        ]);
                        Notification::make()->title("已禁言 {$data['hours']} 小时")->success()->send();
                    }),

                // 永久禁言切换
                Tables\Actions\Action::make('toggle_perma_mute')
                    ->label(fn (Model $r) => ($r->pivot->muted ?? false) ? '解除永久禁言' : '永久禁言')
                    ->icon('heroicon-o-speaker-x-mark')
                    ->color('danger')
                    ->action(function (Model $record) {
                        $now = (bool) ($record->pivot->muted ?? false);
                        $this->getOwnerRecord()->users()->updateExistingPivot($record->id, ['muted' => ! $now]);
                        Notification::make()->title($now ? '已解除' : '已永久禁言')->success()->send();
                    }),

                Tables\Actions\EditAction::make()->label('编辑权限'),

                Tables\Actions\DetachAction::make()->label('踢出群')->color('danger'),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DetachBulkAction::make()->label('批量踢出'),
                    Tables\Actions\BulkAction::make('mute_24h')
                        ->label('批量禁言 24h')
                        ->action(function ($records) {
                            $owner = $this->getOwnerRecord();
                            foreach ($records as $r) {
                                $owner->users()->updateExistingPivot($r->id, [
                                    'muted_until' => now()->addDay(),
                                ]);
                            }
                        }),
                ]),
            ]);
    }
}
