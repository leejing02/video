<?php

namespace App\Filament\Resources\ShortVideoResource\Pages;

use App\Filament\Resources\ShortVideoResource;
use App\Models\Video;
use Filament\Actions;
use Filament\Resources\Components\Tab;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Database\Eloquent\Builder;

class ListShortVideos extends ListRecords
{
    protected static string $resource = ShortVideoResource::class;

    protected function getHeaderActions(): array
    {
        return [Actions\CreateAction::make()->label('上传短视频')];
    }

    public function getTabs(): array
    {
        $pendingCount = Video::query()
            ->where('type', Video::TYPE_SHORT)
            ->where('audit_status', Video::AUDIT_PENDING)->count();

        return [
            'all'      => Tab::make('全部'),
            'pending'  => Tab::make('待审核')
                ->modifyQueryUsing(fn (Builder $q) => $q->where('audit_status', Video::AUDIT_PENDING))
                ->badge($pendingCount)
                ->badgeColor('warning'),
            'approved' => Tab::make('已通过')
                ->modifyQueryUsing(fn (Builder $q) => $q->where('audit_status', Video::AUDIT_APPROVED)),
            'rejected' => Tab::make('已拒绝')
                ->modifyQueryUsing(fn (Builder $q) => $q->where('audit_status', Video::AUDIT_REJECTED)),
        ];
    }
}
