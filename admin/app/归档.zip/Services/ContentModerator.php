<?php

namespace App\Services;

use App\Models\SensitiveWord;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;

/**
 * 敏感词检测服务
 *
 * 用法：
 *   $r = app(ContentModerator::class)->check('要审核的内容');
 *   $r->level   // 'pass' | 'warn' | 'block'
 *   $r->hits    // 命中的词列表
 *
 *   if ($r->isBlocked()) {
 *       // 直接拒绝
 *   } elseif ($r->needsAudit()) {
 *       // 标记 audit_status = pending
 *   }
 */
class ContentModerator
{
    private const CACHE_KEY = 'sensitive_words_v1';
    private const CACHE_TTL = 600; // 10 分钟

    /** @return ModerationResult */
    public function check(?string $text): ModerationResult
    {
        if (! $text) {
            return new ModerationResult('pass', []);
        }
        $words = $this->loadWords();
        if ($words->isEmpty()) {
            return new ModerationResult('pass', []);
        }

        $hits = [];
        $level = 'pass';
        $lower = mb_strtolower($text);
        foreach ($words as $w) {
            if (mb_stripos($lower, mb_strtolower($w->word)) !== false) {
                $hits[] = $w;
                if ($w->severity === SensitiveWord::SEVERITY_BLOCK) {
                    $level = 'block';
                } elseif ($level !== 'block') {
                    $level = 'warn';
                }
            }
        }

        // 异步增加命中计数
        if ($hits) {
            $ids = collect($hits)->pluck('id')->all();
            SensitiveWord::whereIn('id', $ids)->increment('hits');
        }
        return new ModerationResult($level, $hits);
    }

    /** 命中后给一个友好的提示 */
    public function reasonText(ModerationResult $r): string
    {
        if ($r->level === 'pass') return '';
        $words = collect($r->hits)
            ->map(fn ($w) => "{$w->word}（".(SensitiveWord::CATEGORIES[$w->category] ?? $w->category).'）')
            ->implode('、');
        return ($r->level === 'block' ? '违禁词：' : '可疑词：') . $words;
    }

    /** 清缓存 — 在 SensitiveWord 创建/更新/删除时调用 */
    public function flushCache(): void
    {
        Cache::forget(self::CACHE_KEY);
    }

    /** @return Collection<int, SensitiveWord> */
    private function loadWords(): Collection
    {
        return Cache::remember(self::CACHE_KEY, self::CACHE_TTL, function () {
            return SensitiveWord::active()->get(['id', 'word', 'category', 'severity']);
        });
    }
}

class ModerationResult
{
    /** @param SensitiveWord[] $hits */
    public function __construct(
        public readonly string $level, // 'pass' | 'warn' | 'block'
        public readonly array  $hits,
    ) {}

    public function isBlocked(): bool   { return $this->level === 'block'; }
    public function needsAudit(): bool  { return $this->level === 'warn'; }
}
